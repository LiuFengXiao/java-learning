## 简介
Java SE使用BlueCove框架蓝牙连接的Demo，中文社区关于Java SE连接蓝牙的项目是在是太少，在写完蓝牙项目的技术验证后，这里提供了一个简单Demo供参考。
项目包含了以下的内容：
1. 周边蓝牙搜索
2. 作为服务器端被动连接
3. 作为客户端主动连接
## 详情
博客：[Java SE+bluecove  蓝牙连接](http://blog.csdn.net/Svizzera/article/details/77434917)