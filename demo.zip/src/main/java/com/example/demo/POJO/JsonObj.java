package com.example.demo.POJO;

public class JsonObj {
    private int carId;
    private  int  conId;
    private  int speed;
    private  int zhongZhi;
    private  int pid;
    private  int pwmA;
    private  int pwmB;

    public int getCarId() {
        return carId;
    }

    public void setCarId(int carId) {
        this.carId = carId;
    }

    public int getConId() {
        return conId;
    }

    public void setConId(int conId) {
        this.conId = conId;
    }

    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }

    public int getZhongZhi() {
        return zhongZhi;
    }

    public void setZhongZhi(int zhongZhi) {
        this.zhongZhi = zhongZhi;
    }

    public int getPid() {
        return pid;
    }

    public void setPid(int pid) {
        this.pid = pid;
    }

    public int getPwmA() {
        return pwmA;
    }

    public void setPwmA(int pwmA) {
        this.pwmA = pwmA;
    }

    public int getPwmB() {
        return pwmB;
    }

    public void setPwmB(int pwmB) {
        this.pwmB = pwmB;
    }
}
